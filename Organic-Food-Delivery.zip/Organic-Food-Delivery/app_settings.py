from kivy.utils import get_color_from_hex

class AppSettings:
    def __init__(self):
        self.background_color = get_color_from_hex('#FFFFFF')  # Default white
        self.logo_path = './logo.png'  # Default logo path

    def set_background_color(self, color_hex):
        self.background_color = get_color_from_hex(color_hex)

    def set_logo(self, logo_path):
        self.logo_path = logo_path

app_settings = AppSettings()

