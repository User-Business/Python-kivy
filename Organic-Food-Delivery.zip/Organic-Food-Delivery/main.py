from kivy.app import App
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image

# Simulação de banco de dados
users = []
products = [
    {'name': 'Apple', 'price': 1.99, 'sustainability_info': 'Organic apple from local farms', 'image': 'product1.png'},
    {'name': 'Carrot', 'price': 0.99, 'sustainability_info': 'Sustainably grown carrot', 'image': 'product2.png'}
]
sustainability_tips = [
    "Buy local products to reduce carbon footprint.",
    "Opt for seasonal fruits and vegetables.",
    "Use reusable bags for shopping."
]

# Gerenciador de Telas
class WindowManager(ScreenManager):
    pass

# Tela de Registro
class RegisterScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        self.name_input = TextInput(hint_text='Name')
        self.email_input = TextInput(hint_text='Email')
        self.phone_input = TextInput(hint_text='Phone')
        self.password_input = TextInput(hint_text='Password', password=True)
        register_button = Button(text='Register', on_press=self.register_user)
        layout.add_widget(Label(text='Register'))
        layout.add_widget(self.name_input)
        layout.add_widget(self.email_input)
        layout.add_widget(self.phone_input)
        layout.add_widget(self.password_input)
        layout.add_widget(register_button)
        self.add_widget(layout)

    def register_user(self, instance):
        users.append({
            'name': self.name_input.text,
            'email': self.email_input.text,
            'phone': self.phone_input.text,
            'password': self.password_input.text
        })
        self.manager.current = 'login'

# Tela de Login
class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        self.email_phone_input = TextInput(hint_text='Email or Phone')
        self.password_input = TextInput(hint_text='Password', password=True)
        login_button = Button(text='Login', on_press=self.authenticate_user)
        layout.add_widget(Label(text='Login'))
        layout.add_widget(self.email_phone_input)
        layout.add_widget(self.password_input)
        layout.add_widget(login_button)
        self.add_widget(layout)

    def authenticate_user(self, instance):
        for user in users:
            if (user['email'] == self.email_phone_input.text or user['phone'] == self.email_phone_input.text) and user['password'] == self.password_input.text:
                self.manager.current = 'catalog'
                return
        print("Invalid credentials")

# Tela de Catálogo
class CatalogScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        for product in products:
            product_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=100)
            product_image = Image(source=product['image'], size_hint=(0.3, 1))
            product_button = Button(text=f"{product['name']} - R${product['price']:.2f}", size_hint=(0.7, 1),
                                     on_press=lambda x, prod=product: self.show_product_details(prod))
            product_layout.add_widget(product_image)
            product_layout.add_widget(product_button)
            layout.add_widget(product_layout)
        self.add_widget(layout)

    def show_product_details(self, product):
        self.manager.get_screen('product_details').set_product(product)
        self.manager.current = 'product_details'


# Tela de Detalhes do Produto
class ProductDetailsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        self.product_image = Image(size_hint=(1, 0.5))
        self.product_label = Label()
        self.product_price = Label()
        self.sustainability_info = Label()
        buy_button = Button(text='Buy', on_press=self.simulate_purchase)
        layout.add_widget(self.product_image)
        layout.add_widget(self.product_label)
        layout.add_widget(self.product_price)
        layout.add_widget(self.sustainability_info)
        layout.add_widget(buy_button)
        self.add_widget(layout)

    def set_product(self, product):
        self.product_image.source = product['image']
        self.product_label.text = f"Product: {product['name']}"
        self.product_price.text = f"Price: R${product['price']:.2f}"
        self.sustainability_info.text = f"Sustainability Info: {product['sustainability_info']}"
        self.selected_product = product
    def simulate_purchase(self, instance):
        tip = sustainability_tips[0]
        self.manager.get_screen('confirmation').set_confirmation(tip)
        self.manager.current = 'confirmation'

# Tela de Confirmação de Compra
class ConfirmationScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        self.thank_you_image = Image(size_hint=(1, 0.5))
        self.tip_label = Label()
        back_button = Button(text='Back to Catalog', on_press=self.back_to_catalog)
        self.layout.add_widget(self.thank_you_image)
        self.layout.add_widget(self.tip_label)
        self.layout.add_widget(back_button)
        self.add_widget(self.layout)

    def set_confirmation(self, tip):
        self.thank_you_image.source = "./obrigado.png"  # Adicione sua imagem na pasta do projeto
        self.tip_label.text = f"Sustainability Tip: {tip}"

    def back_to_catalog(self, instance):
        self.manager.current = 'catalog'

# Aplicativo Principal
class OrganicFoodDeliveryApp(App):
    def build(self):
        self.title = "Organic Food Delivery"
        sm = WindowManager()
        sm.add_widget(RegisterScreen(name='register'))
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(CatalogScreen(name='catalog'))
        sm.add_widget(ProductDetailsScreen(name='product_details'))
        sm.add_widget(ConfirmationScreen(name='confirmation'))
        return sm

if __name__ == '__main__':
    OrganicFoodDeliveryApp().run()
